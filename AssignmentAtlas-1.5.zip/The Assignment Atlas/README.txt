The Assignment Atlas  (version 1.5)
=====================================

TO INSTALL
1. Unzip this file if you haven't already.
2. Double-click  Install.command
   If macOS says it can't be opened, right-click it and choose "Open"
   instead of double-clicking, then confirm in the dialog.
3. The app opens.

DO IT BY HAND INSTEAD (if the script won't run)
   xattr -dr com.apple.quarantine "The Assignment Atlas.app"
   mkdir -p ~/Applications
   rm -rf "~/Applications/The Assignment Atlas.app"
   cp -R "The Assignment Atlas.app" ~/Applications/
   open "~/Applications/The Assignment Atlas.app"

WHY THE PROMPT
This app was built and signed for free, without an Apple Developer account,
so macOS warns about it once. The commands above clear that flag. Nothing here
needs an administrator password.

YOUR DATA
Assignments, classes, and tests are stored in
    ~/Library/Application Support/The Assignment Atlas/
That folder is outside the app, so installing, updating, or deleting the app
never touches your data. Updates also keep a rolling backup there.

UPDATES
Open Settings -> Software update and press "Check for updates". New builds are
pulled from GitHub and installed over this one without touching your data.
