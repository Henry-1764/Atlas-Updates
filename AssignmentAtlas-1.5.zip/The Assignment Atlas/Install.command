#!/bin/bash
# The Assignment Atlas — one-shot installer. Double-click it, or run it from Terminal.
set -eu
cd "$(dirname "$0")"

NAME="The Assignment Atlas"
SRC="$PWD/$NAME.app"
DEST="$HOME/Applications/$NAME.app"

if [ ! -d "$SRC" ]; then
    echo "error: $NAME.app not found next to this script."
    echo "Keep Install.command in the same folder as the app."
    exit 1
fi

# Gatekeeper marks downloaded files; the app is not notarised (no paid Apple
# account involved), so drop the quarantine attribute ourselves. No sudo needed.
echo "Removing Gatekeeper quarantine…"
xattr -dr com.apple.quarantine "$SRC" 2>/dev/null || true

echo "Waiting for any running copy to quit…"
osascript -e 'tell application "The Assignment Atlas" to quit' >/dev/null 2>&1 || true
sleep 1

mkdir -p "$HOME/Applications"
echo "Installing to $DEST"
rm -rf "$DEST"
ditto "$SRC" "$DEST"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true

echo
echo "Done — launching."
echo "Your assignments and classes live outside the app and are never touched."
echo
open "$DEST"
read -r -n 1 -s -p "Press any key to close…" || true
echo
